
This System in Django created based on python3.8 , Django, and SQLITE3 Database.

A CRUD In Django Python is a simple web based project which is very easy to understand and use. The user can Create, Read, Update and Delete their Date inside the database.

What is crud app?

Create, Read, Update, and Delete is referred to as CRUD. These four fundamental procedures are carried out on database models. 

    Reading Operation: the application’s capacity to read data from a database.
    Launch an operation: the application’s capacity to store information in a database.
    Operation Update: the capacity of the program to change database stored value.
    Operation Delete: the application’s capacity to remove a value from a database.


Features Of This Project CRUD App In Django

    Add Information – This feature, the user can add their “firstname” and “lastname” information inside the database.
    Update Information – This feature, the user can “edit” or “update” their information inside the database.
    Delete Information – This feature, the user are free to “delete” or “remove” their adding information from the database.
    Display Information – This feature, the system display all the information that are inside the database.

In This Project CRUD App In Django Consist Of The Following Method:

    crud – In this method which is the main method of the system project, In this method you can perform on how to “Create” , “Read” , “Update” and “Delete” and also in this method you can found the template   design of a website like HTML and CSS.
    web – In this method which is direct location when you run the project.
    
    

How To Run
    Step 1: Extract/unzip the file
    Step 2: Go inside the project folder, open cmd, and type the following commands to install Django Framework and run the webserver:
    python manage.py migrate
    python manage.py runserver
    Step 3: Finally, open the browser and go to http://127.0.0.1:8000/


