/* @license MIT https://raw.githubusercontent.com/js-cookie/js-cookie/v3.0.5/LICENSE */
!function(e,t){"object"==typeof exports&&"undefined"!=typeof module?module.exports=t():"function"==typeof define&&define.amd?define(t):(e="undefined"!=typeof globalThis?globalThis:e||self,function(){var n=e.Cookies,o=e.Cookies=t();o.noConflict=function(){return e.Cookies=n,o;};}());}(this,(function(){"use strict";function e(e){for(var t=1;t<arguments.length;t++){var n=arguments[t];for(var o in n)e[o]=n[o];}return e;}var t=function t(n,o){function r(t,r,i){if("undefined"!=typeof document){"number"==typeof (i=e({},o,i)).expires&&(i.expires=new Date(Date.now()+864e5*i.expires)),i.expires&&(i.expires=i.expires.toUTCString()),t=encodeURIComponent(t).replace(/%(2[346B]|5E|60|7C)/g,decodeURIComponent).replace(/[()]/g,escape);var c="";for(var u in i)i[u]&&(c+="; "+u,!0!==i[u]&&(c+="="+i[u].split(";")[0]));return document.cookie=t+"="+n.write(r,t)+c;}}return Object.create({set:r,get:function(e){if("undefined"!=typeof document&&(!arguments.length||e)){for(var t=document.cookie?document.cookie.split("; "):[],o={},r=0;r<t.length;r++){var i=t[r].split("="),c=i.slice(1).join("=");try{var u=decodeURIComponent(i[0]);if(o[u]=n.read(c,u),e===u)break;}catch(e){}}return e?o[e]:o;}},remove:function(t,n){r(t,"",e({},n,{expires:-1}));},withAttributes:function(n){return t(this.converter,e({},this.attributes,n));},withConverter:function(n){return t(e({},this.converter,n),this.attributes);}},{attributes:{value:Object.freeze(o)},converter:{value:Object.freeze(n)}});}({read:function(e){return '"'===e[0]&&(e=e.slice(1,-1)),e.replace(/(%[\dA-F]{2})+/gi,decodeURIComponent);},write:function(e){return encodeURIComponent(e).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,decodeURIComponent);}},{path:"/"});return t;}));;
/* @license GPL-2.0-or-later https://www.drupal.org/licensing/faq */
(function(window){if(!window.rhdp_fe_app)window.rhdp_fe_app={sso:{attached:0},page_state:{attached:0},file_download:{attached:0,is_download_page:false}};if(!window.rhdp_fe_app.sso)window.rhdp_fe_app.sso={attached:0};if(!window.rhdp_fe_app.page_state)window.rhdp_fe_app.page_state={attached:0};if(!window.rhdp_fe_app.file_download)window.rhdp_fe_app.file_download={attached:0,is_download_page:false};window.rhdp_fe_app.urlParam=(name)=>{let queryString=window.location.search;let urlParams=new URLSearchParams(queryString);return urlParams.get(name);};let isDownloadURL=window.rhdp_fe_app.urlParam("tcDownloadURL")?true:false;let isDownloadFileName=window.rhdp_fe_app.urlParam("tcDownloadFileName")?true:false;let isProduct=window.rhdp_fe_app.urlParam("p")?true:false;if(isDownloadURL&&isDownloadFileName&&isProduct)window.rhdp_fe_app.file_download.is_download_page=true;else window.rhdp_fe_app.file_download.is_download_page=false;})(window);;
(function($,Drupal,rhdp_fe_app){Drupal.behaviors.page_state={attach:function(context,settings){rhdp_fe_app.page_state.attached++;if(rhdp_fe_app.page_state.attached>1)return;const _first_array_item=0;const _zero=0;const maxRegTime=86400000;document.addEventListener("pageUserUpdate",function(){pageUserUpdate();});document.addEventListener("updatePageUserAnalytics",function(){updatePageUserAnalytics();});document.addEventListener("updateAudienceSelectionState",function(){updateAudienceSelectionState();});function updateNavLoginState(){let tmp_keycloak=rhdp_fe_app.rhdKeycloak;let isAuthenticated=false;if(tmp_keycloak&&tmp_keycloak.authenticated)isAuthenticated=tmp_keycloak.authenticated;if(typeof rhAccountDropdown==="undefined"||rhAccountDropdown===null)return;if(isAuthenticated){if(rhAccountDropdown.hasDropdownComponent()){let mappedUserData={realm_access:tmp_keycloak.tokenParsed.realm_access,REDHAT_LOGIN:tmp_keycloak.tokenParsed.preferred_username,lastName:tmp_keycloak.tokenParsed.family_name?tmp_keycloak.tokenParsed.family_name:"User",account_number:tmp_keycloak.tokenParsed.rh_account_number,preferred_username:tmp_keycloak.tokenParsed.preferred_username,firstName:tmp_keycloak.tokenParsed.given_name?tmp_keycloak.tokenParsed.given_name:"RHD ",email:tmp_keycloak.tokenParsed.email,username:tmp_keycloak.tokenParsed.name};rhAccountDropdown.setLogOutState(mappedUserData);}}else{if(rhAccountDropdown.hasDropdownComponent())rhAccountDropdown.setLogInState();}}function updateAudienceSelectionState(){let tmp_keycloak=rhdp_fe_app.rhdKeycloak;let isAuthenticated=false;if(tmp_keycloak&&tmp_keycloak.authenticated)isAuthenticated=tmp_keycloak.authenticated;let authenticationValueShow;let authenticationValueRemove;let skipAudienceCheck=false;let onPageNav;let onPageNavItems;authenticationValueShow=isAuthenticated?"authenticated":"unauthenticated";authenticationValueRemove=isAuthenticated?"unauthenticated":"authenticated";if(drupalSettings.rhd_admin&&drupalSettings.rhd_admin["disable-audience-selection-display"]){skipAudienceCheck=true;$("[data-audience]").css("display","").addClass("rhd-show-auth-status");}onPageNav=document.querySelector(".assembly-type-on_page_navigation");if(onPageNav!==null){document.querySelectorAll('[data-audience="'+authenticationValueRemove+'"]').forEach(function(e){let hrefVal="#"+e.id;$(onPageNav.querySelector('a[href^="'+hrefVal+'"')).detach();});onPageNavItems=onPageNav.querySelectorAll("a");onPageNavItems.forEach(function(e){e.style.visibility="visible";});}if(!skipAudienceCheck){$('[data-audience="'+authenticationValueShow+'"]').show();$('[data-audience="'+authenticationValueRemove+'"]').detach();}}function updatePageUserAnalytics(){let usr;let ddUserAuthEvent;prepareUserData();window.digitalData=window.digitalData||{};window.digitalData.user=window.digitalData.user||[{profile:[{profileInfo:{}}]}];usr=window.digitalData.user[_first_array_item].profile[_first_array_item].profileInfo;ddUserAuthEvent={eventInfo:{eventName:"user data",eventAction:"available",user:[{profile:[{profileInfo:usr}]}],timeStamp:new Date(),processed:{adobeAnalytics:false}}};window.digitalData.event=window.digitalData.event||[];window.digitalData.event.push(ddUserAuthEvent);sendCustomEvent('ajaxAuthEvent');window.rhd_userDataSent=1;}function pageUserUpdate(){let tmp_keycloak=rhdp_fe_app.rhdKeycloak;let isAuthenticated=false;if(tmp_keycloak&&tmp_keycloak.authenticated)isAuthenticated=tmp_keycloak.authenticated;if(isAuthenticated)$("a.rhd-c-login-button").on("click",function(e){e.preventDefault();let redirectUri=rhdp_fe_app.page_state.createRedirectUri();window.location.href=redirectUri;});else $("a.rhd-c-login-button").on("click",function(e){e.preventDefault();let redirectUri=rhdp_fe_app.page_state.createRedirectUri();tmp_keycloak.login({redirectUri});});updateNavLoginState();}rhdp_fe_app.page_state.createRedirectUri=function(){let destination=window.location.protocol+"//"+window.location.host;if(window.location.pathname==="/user/login")return destination+"/contributor/dashboard?source=sso";const queryString=window.location.search;const urlParams=new URLSearchParams(queryString);if(!queryString)return window.location.href+"?source=sso";if(queryString&&urlParams.get("source"))return window.location.href;return window.location.href+"&source=sso";};function getCookie(name){let re=new RegExp("(?:(?:^|.*;\\s*)"+name+"\\s*\\=\\s*([^;]*).*$)|^.*$");return document.cookie.replace(re,"$1");}function prepareUserData(){let tmp_keycloak=rhdp_fe_app.rhdKeycloak;let isAuthenticated=false;if(tmp_keycloak&&tmp_keycloak.authenticated)isAuthenticated=tmp_keycloak.authenticated;let usr={};let swelHeaders;window.digitalData=window.digitalData||{};window.digitalData.user=window.digitalData.user||[{profile:[{profileInfo:{}}]}];usr=window.digitalData.user[_first_array_item].profile[_first_array_item].profileInfo;if(isAuthenticated){usr.loggedIn=true;usr.keyCloakID=tmp_keycloak.tokenParsed.id;usr.socialAccountsLinked=[];if(tmp_keycloak.tokenParsed["user-social-links"]){for(let social in tmp_keycloak.tokenParsed["user-social-links"])if(social!=='')usr.socialAccountsLinked.push(social);}if(Headers&&tmp_keycloak.token&&drupalSettings.rhd.swel.url){swelHeaders=new Headers();swelHeaders.append("Authorization","Bearer "+tmp_keycloak.token);fetch(drupalSettings.rhd.swel.url+"/api/analytics/usr/v1/websiteregstatus/rhd",{method:"GET",headers:swelHeaders,mode:"cors"}).then(function(req){return req.json();}).then(function(resp){let dt;let rt;let ck;if(resp&&resp.registrationTimestamp){dt=new Date().getTime();rt=new Date(resp.registrationTimestamp).getTime();ck=getCookie("rhd_logged");if(dt-rt<maxRegTime&&ck.length===_zero){document.cookie="rhd_logged=true; expires=Fri, 31 Dec 9999 23:59:59 GMT";document.cookie="rhd_registered=true; expires=Fri, 31 Dec 9999 23:59:59 GMT";}}});}}window.digitalData.user[_first_array_item].profile[_first_array_item].profileInfo=usr;}let isLayoutBuilderForm=document.querySelector(".node-layout-builder-form");if(isLayoutBuilderForm!==null)$(document).ajaxComplete(function(){document.dispatchEvent(new Event("updateAudienceSelectionState"));});}};})(jQuery,Drupal,rhdp_fe_app);;
(function($,window){var htmlSpecialCharsRegEx=/[<>&\r\n"']/gm;var htmlSpecialCharsPlaceHolders={'<':'lt;','>':'gt;','&':'amp;','\r':"#13;",'\n':"#10;",'"':'quot;',"'":'#39;'};$.extend({fileDownload:function(fileUrl,options){var settings=$.extend({preparingMessageHtml:null,failMessageHtml:null,androidPostUnsupportedMessageHtml:"Unfortunately your Android browser doesn't support this type of file download. Please try again with a different browser.",dialogOptions:{modal:true},prepareCallback:function(url){},successCallback:function(url){},abortCallback:function(url){},failCallback:function(responseHtml,url,error){},httpMethod:"GET",data:null,checkInterval:100,cookieName:"fileDownload",cookieValue:"true",cookiePath:"/",cookieDomain:null,popupWindowTitle:"Initiating file download...",encodeHTMLEntities:true},options);var deferred=new $.Deferred();var userAgent=(navigator.userAgent||navigator.vendor||window.opera).toLowerCase();var isIos;var isAndroid;var isOtherMobileBrowser;if(/ip(ad|hone|od)/.test(userAgent))isIos=true;else if(userAgent.indexOf('android')!==-1)isAndroid=true;else isOtherMobileBrowser=/avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|playbook|silk|iemobile|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(userAgent)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|e\-|e\/|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(di|rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|xda(\-|2|g)|yas\-|your|zeto|zte\-/i.test(userAgent.substr(0,4));var httpMethodUpper=settings.httpMethod.toUpperCase();if(isAndroid&&httpMethodUpper!=="GET"&&settings.androidPostUnsupportedMessageHtml){if($().dialog)$("<div>").html(settings.androidPostUnsupportedMessageHtml).dialog(settings.dialogOptions);else alert(settings.androidPostUnsupportedMessageHtml);return deferred.reject();}var $preparingDialog=null;var internalCallbacks={onPrepare:function(url){if(settings.preparingMessageHtml)$preparingDialog=$("<div>").html(settings.preparingMessageHtml).dialog(settings.dialogOptions);else{if(settings.prepareCallback)settings.prepareCallback(url);}},onSuccess:function(url){if($preparingDialog)$preparingDialog.dialog('close');settings.successCallback(url);deferred.resolve(url);},onAbort:function(url){if($preparingDialog)$preparingDialog.dialog('close');;settings.abortCallback(url);deferred.reject(url);},onFail:function(responseHtml,url,error){if($preparingDialog)$preparingDialog.dialog('close');if(settings.failMessageHtml)$("<div>").html(settings.failMessageHtml).dialog(settings.dialogOptions);settings.failCallback(responseHtml,url,error);deferred.reject(responseHtml,url);}};internalCallbacks.onPrepare(fileUrl);if(settings.data!==null&&typeof settings.data!=="string")settings.data=$.param(settings.data);var $iframe,downloadWindow,formDoc,$form;if(httpMethodUpper==="GET"){if(settings.data!==null){var qsStart=fileUrl.indexOf('?');if(qsStart!==-1){if(fileUrl.substring(fileUrl.length-1)!=="&")fileUrl=fileUrl+"&";}else fileUrl=fileUrl+"?";fileUrl=fileUrl+settings.data;}if(isIos||isAndroid){downloadWindow=window.open(fileUrl);downloadWindow.document.title=settings.popupWindowTitle;window.focus();}else if(isOtherMobileBrowser)window.location(fileUrl);else $iframe=$("<iframe style='display: none' src='"+fileUrl+"'></iframe>").appendTo("body");}else{var formInnerHtml="";if(settings.data!==null)$.each(settings.data.replace(/\+/g,' ').split("&"),function(){var kvp=this.split("=");var k=kvp[0];kvp.shift();var v=kvp.join("=");kvp=[k,v];var key=settings.encodeHTMLEntities?htmlSpecialCharsEntityEncode(decodeURIComponent(kvp[0])):decodeURIComponent(kvp[0]);if(key){var value=settings.encodeHTMLEntities?htmlSpecialCharsEntityEncode(decodeURIComponent(kvp[1])):decodeURIComponent(kvp[1]);formInnerHtml+='<input type="hidden" name="'+key+'" value="'+value+'" />';}});if(isOtherMobileBrowser){$form=$("<form>").appendTo("body");$form.hide().prop('method',settings.httpMethod).prop('action',fileUrl).html(formInnerHtml);}else{if(isIos){downloadWindow=window.open("about:blank");downloadWindow.document.title=settings.popupWindowTitle;formDoc=downloadWindow.document;window.focus();}else{$iframe=$("<iframe style='display: none' src='about:blank'></iframe>").appendTo("body");formDoc=getiframeDocument($iframe);}formDoc.write("<html><head></head><body><form method='"+settings.httpMethod+"' action='"+fileUrl+"'>"+formInnerHtml+"</form>"+settings.popupWindowTitle+"</body></html>");$form=$(formDoc).find('form');}$form.submit();}setTimeout(checkFileDownloadComplete,settings.checkInterval);function checkFileDownloadComplete(){var cookieValue=settings.cookieValue;if(typeof cookieValue=='string')cookieValue=cookieValue.toLowerCase();var lowerCaseCookie=settings.cookieName.toLowerCase()+"="+cookieValue;if(document.cookie.toLowerCase().indexOf(lowerCaseCookie)>-1){internalCallbacks.onSuccess(fileUrl);var cookieData=settings.cookieName+"=; path="+settings.cookiePath+"; expires="+new Date(0).toUTCString()+";";if(settings.cookieDomain)cookieData+=" domain="+settings.cookieDomain+";";document.cookie=cookieData;cleanUp(false);return;}if(downloadWindow||$iframe)try{var formDoc=downloadWindow?downloadWindow.document:getiframeDocument($iframe);if(formDoc&&formDoc.body!==null&&formDoc.body.innerHTML.length){var isFailure=true;if($form&&$form.length){var $contents=$(formDoc.body).contents().first();try{if($contents.length&&$contents[0]===$form[0])isFailure=false;}catch(e){if(e&&e.number==-2146828218)isFailure=true;else throw e;}}if(isFailure){setTimeout(function(){internalCallbacks.onFail(formDoc.body.innerHTML,fileUrl);cleanUp(true);},100);return;}}}catch(err){internalCallbacks.onFail('',fileUrl,err);cleanUp(true);return;}setTimeout(checkFileDownloadComplete,settings.checkInterval);}function getiframeDocument($iframe){var iframeDoc=$iframe[0].contentWindow||$iframe[0].contentDocument;if(iframeDoc.document)iframeDoc=iframeDoc.document;return iframeDoc;}function cleanUp(isFailure){setTimeout(function(){if(downloadWindow){if(isAndroid)downloadWindow.close();if(isIos)if(downloadWindow.focus){downloadWindow.focus();if(isFailure)downloadWindow.close();}}},0);}function htmlSpecialCharsEntityEncode(str){return str.replace(htmlSpecialCharsRegEx,function(match){return '&'+htmlSpecialCharsPlaceHolders[match];});}var promise=deferred.promise();promise.abort=function(){cleanUp();$iframe.attr('src','').html('');internalCallbacks.onAbort(fileUrl);};return promise;}});})(jQuery,this||window);;
(function($,Drupal,rhdp_fe_app){Drupal.behaviors.rhdp_fe_file_download={attach:function(context,settings){rhdp_fe_app.file_download.attached++;if(rhdp_fe_app.file_download.attached>1)return;const downloadTypes=["media","cloud","product","eol","gated asset","gated course","gated link","gated trial","redirect"];document.addEventListener("rhdp_feDownloadFile",function(){download();});document.addEventListener("rhdp_feHideDownloadMessage",function(){hideDownloadMessage();});function hideDownloadMessage(){$("div#downloadthankyou").hide();}function getAlertTemplate(tmpDownloadUrl){const messageTemplate=`
          <div class="component rhd-m-max-width-xl rhd-c-product-download-alert pf-c-content pf-u-py-xl" id="downloadthankyou">
              <div class="pf-c-alert pf-m-success" aria-label="Success alert">
                  <div class="pf-c-alert__icon">
                      <i class="fas fa-fw fa-check-circle" aria-hidden="true"></i>
                  </div>
                  <p class="pf-c-alert__title pf-u-font-size-2xl">
                      <span class="pf-screen-reader">Success alert:</span>
                      Thank you for downloading!
                  </p>
                  <div class="pf-c-alert__description">
                      <p>
                      Your download should start automatically.
                      If you have any problems with the download, please use the
                      <a id="tcDownloadLink" href="${tmpDownloadUrl}"> direct link</a>.
                      </p>
                  </div>
              </div>
          </div>
          `;return messageTemplate;}function download(){let tcDownloadURL=encodeURI(rhdp_fe_app.urlParam("tcDownloadURL"));let tcDownloadFileName=encodeURI(rhdp_fe_app.urlParam("tcDownloadFileName"));let product=rhdp_fe_app.urlParam("p");product=decodeURI(product);let productArray=product.split(':');if(Array.isArray(productArray)&&productArray.length>=2&&downloadTypes.includes(productArray[0].toLowerCase())){productArray.shift();product=productArray.join(":");}let tcProduct=product.trim();let ddDownloadEvent={eventInfo:{eventAction:"download",eventName:"download",fileName:tcDownloadFileName,fileType:tcProduct,productDetail:tcProduct,timeStamp:new Date(),processed:{adobeAnalytics:false}}};tcDownloadURL=tcDownloadURL.replace("&source=sso","");if(rhdp_fe_app.file_download.is_download_page&&tcDownloadURL&&tcProduct)$("main").prepend(getAlertTemplate(tcDownloadURL));if(rhdp_fe_app.file_download.is_download_page&&tcDownloadURL&&tcDownloadURL.startsWith("https://access.cdn.redhat.com/")&&tcDownloadURL.includes(tcDownloadFileName)){$.fileDownload(tcDownloadURL);pushDataLayerProductDownload(tcDownloadFileName,tcProduct);}sendTrackingData(ddDownloadEvent);}function pushDataLayerProductDownload(downloadFileName,product){if(!downloadFileName)return;window.dataLayer=window.dataLayer||[];window.dataLayer.push({product_download_file_name:downloadFileName});window.dataLayer.push({event:"Product Download Requested"});document.dispatchEvent(new ReporterEvent("Download Started",{fileName:downloadFileName,fileType:downloadFileName.split('.').pop(),product:[{productInfo:{name:product,productID:'',sku:''}}]}));}function sendTrackingData(tmpDdDownloadEvent){if(!tmpDdDownloadEvent)return;window.digitalData=window.digitalData||{};digitalData.event=digitalData.event||[];digitalData.event.push(tmpDdDownloadEvent);sendCustomEvent("downloadEvent");}}};})(jQuery,Drupal,window.rhdp_fe_app);;
/* eslint-disable no-magic-numbers */
(function ($, Drupal) {
  let seeMoreArray = [];
  Drupal.behaviors.view_exposed_filters = {
    attach: function (context, settings) {
      if (context !== document) {
        return;
      }

      let accordions = $("details.form-wrapper", context);

      function seeMoreButton() {
        accordions.each(function (index) {
          let accordion = $(this);
          let filterOptions = accordion.find(
            ".form-checkboxes.bef-checkboxes"
          );
          let options = filterOptions.find(".js-form-type-checkbox");
          let seeMoreButton = $("<button>")
            .text("See More")
            .addClass(
              `pf-m-primary pf-u-mr-md pf-u-ml-0 see-more see-more-${index}`
            );
          seeMoreButton.on("click", function (e) {
            seeMoreArray.push(`see-more-${index}`);
            options.slice(5).show();
            e.preventDefault();
            seeMoreButton.hide();
          });

          if (options.length > 5) {
            accordion.append(seeMoreButton);
            options.slice(5).hide();
          }

          if (seeMoreArray.length > 0) {
            seeMoreArray.forEach(function (item) {
              let seeMoreClickedButton = accordion.find(`.${item}`);
              seeMoreClickedButton.hide();
              let options = seeMoreClickedButton
                .siblings(".form-checkboxes")
                .find(".js-form-type-checkbox");
              options.slice(5).show();
            });
          }
        });
      }

      // Add the see more buttons.
      seeMoreButton();

      function accordionForMobile(tmp_accordions) {
        tmp_accordions.each(function () {
          let filterOptions = $(this).find(
            ".form-checkboxes.bef-checkboxes"
          );
          let options = filterOptions.find(".js-form-type-checkbox");
          if ($(window).innerWidth() < 768) {
            $(this).removeAttr("open");
            options.each(function () {
              if ($(this).find('input[type="checkbox"]').is(":checked")) {
                let accordion = $(this).parents('.form-wrapper')
                accordion.attr("open", "open");
              }
            })
          } else {
            $(this).attr("open", "open");
          }
        });
      }

      // When mobile close filters.
      accordionForMobile(accordions);

      // When mobile close filters on resize.
      $(window).resize(function () {
        clearTimeout($.data(this, 'resizeTimer'));
        $.data(this, 'resizeTimer', setTimeout(function() {
          accordionForMobile(accordions)
        }, 150));
      })

      // Process initial accordions.
      accordions.each(function () {
        let accordion = $(this);
        let filterOptions = accordion.find(".form-checkboxes.bef-checkboxes");
        let options = filterOptions.find(".js-form-type-checkbox");

        // Move selected options to the top within their parent
        if (options.length > 5) {
          let selectedInputs = options.find('input[type="checkbox"]:checked');
          selectedInputs.each(function () {
            let parentOption = $(this).closest(".js-form-type-checkbox");
            parentOption.prependTo(filterOptions);
          });
        }

        // Update options when any checkbox gets checked.
        options.each(function () {
          let checkbox = $(this).find('input[type="checkbox"]');
          checkbox.on("change", function () {
            updateFilterOptions(accordion);
          });
        });

        // Add number of items attribute and show attribute.
        accordion.attr("item-count", options.length);
        if (options.length === 0) {
          accordion.attr("show-item", 'no');
        } else {
          accordion.attr("show-item", 'yes');
        }
      });

      //Update filter options
      function updateFilterOptions(accordion) {
        let filterOptions = accordion.find(".form-checkboxes.bef-checkboxes");
        let options = filterOptions.find(".js-form-type-checkbox");
        let selectedOptions = [];
        let unselectedOptions = [];

        //Iterate over all options and push them to their arrays.
        if (options.length > 5){
          options.each(function () {
            if ($(this).find('input[type="checkbox"]').is(":checked")) {
              selectedOptions.push(this);
            } else {
              unselectedOptions.push(this);
            }
          });

          filterOptions.empty();
          selectedOptions.forEach(function (option) {
            filterOptions.append(option);
          });
          unselectedOptions.forEach(function (option) {
            filterOptions.append(option);
          });
        }

        // Add number of items attribute and show attribute.
        accordion.attr("item-count", options.length);
        if (options.length === 0) {
          accordion.attr("show-item", 'no');
        } else {
          accordion.attr("show-item", 'yes');
        }
      }

      // RHDX-4913: Adding functionality to remove query parameters after clicking reset button.
      $('input[name="reset"]').on('click', function() {
        var newUrl = window.location.href.split('?')[0];
        $.ajax({
          url: newUrl,
          type: 'GET',
          success: function(data) {
            history.pushState(null, null, newUrl);
          },
          error: function(error) {
            console.error('Ajax request failed:', error);
          }
        });
      });

      // Reattach behavior after each AJAX request
      if (settings.ajax) {
        $(document).ajaxComplete(function () {
          // Get the latest accordion values.
          let accordions = $("details.form-wrapper", context);
          accordions.each(function () {
            updateFilterOptions($(this));
          });
        });
      }
    }
  };
})(jQuery, Drupal);
;
